# _SLATE-BIBLE-BURNED-NEXT4.md — the assignment (Parts VI-IX)
### Channel: sacred_dawn · Voice: Elliot (channel.json handles it) · One video at a time, IN ORDER.
### Every video: full process per _BRIEFCASE-INSTRUCTIONS §1 (Step 0 sign-off → river → READ pass → chop → gate loop → src set). BOM ceiling $30/video — exceed it only by stopping and flagging.

---

## THE FOUR PACKAGES

### PART VI — "The Gospel of Thomas: The Bible's Forbidden Twin"  (slug: gospel-of-thomas)
The full film the teaser promised (the teaser = the jar dig; its src is your example-src — REUSE its cold-open imagery as a callback, do not re-shoot the teaser). Source: the Coptic Gospel of Thomas, 114 sayings, Nag Hammadi codex II (public-domain translations; Lambdin/Patterson-Meyer phrasing as reference, paraphrase in our register). Angle: a gospel with no story at all — no birth, no miracles, no trial, no cross — only the voice: "whoever finds the meaning of these words will not taste death." Structure: the jar frame (burial 367 AD → spade 1945) wrapping a guided descent through the sayings in themed movements (the kingdom is spread upon the earth; the light within; the burning sayings "I have cast fire upon the world"; the twin motif — Didymos Judas Thomas, "the twin" — and why a sayings-only Jesus terrified the canon-makers). Runtime 60-75 min ≈ 10,500-12,500 words. ~260-310 beats. Kling 12-15 via the authored `kling` column: cold-open saturation (jar/desert/fire imagery) + movement-opener pairs + 3-4 saying-heroes (fire cast on the world; the light-filled man; the buried jar opening).

### PART VII — "The Book of Jasher: The Bible's Missing Source"  (slug: book-of-jasher)
Source: the Bible's own two citations ("Is it not written in the book of Jasher?" — Joshua 10:13 at the sun standing still; 2 Samuel 1:18 at David's bow-lament) + the medieval Sefer haYashar as the claimant text. HONESTY LAW for this film: the surviving "Jasher" is a medieval Hebrew work, not the lost original — the film's spine IS that hunt (the book the Bible quotes, the vanishing, the claimants, the 1751 forgery, the 1840 Mormon printing, what the claimant text actually adds: expanded Abraham-in-the-furnace, Jacob's wars). Play it as a detective story; the integrity is the differentiator. Runtime 55-70 min ≈ 9,500-12,000 words. Kling 12-14: sun-stands-still hero (Law 29: make the frozen sun otherworldly, a sky that has stopped), furnace of Nimrod hero, the citation-scroll motif.

### PART VIII — "The Testament of Solomon: The King Who Commanded Demons"  (slug: testament-of-solomon)
Source: the Testament of Solomon (1st-3rd c. Greek, public domain, Conybeare translation as reference). Angle: the banned manual where Solomon, given a ring by Michael, interrogates and conscripts demons to build the temple — a roster of named spirits, their works, and what undoes each — until the king's own fall ends the charter. The highest-CTR subject on this slate; also the highest Law-28 risk: demons are CONTINUOUS PHENOMENA (smoke, shadow, mist, fire, wind-shapes) in witness grammar — never contact events, never transformation on-screen outside an explicitly declared dream/vision register zone. Canon-lock the ring (one design, every appearance). Runtime 55-70 min ≈ 9,500-12,000 words. Kling 12-15: ring-bestowal hero, temple-rising-by-night hero, 2-3 demon-phenomenon setpieces.

### PART IX — "The Apocalypse of Peter: The Banned Book of Heaven and Hell"  (slug: apocalypse-of-peter)
Source: the Apocalypse of Peter (Ethiopic + Akhmim Greek, public domain). Angle: the OTHER apocalypse — the one that nearly made your Bible (the Muratorian fragment lists it beside John's, "though some will not have it read"), the first Christian guided tour of heaven and hell, the grandfather of Dante — and why the canon kept the dragon and dropped the tour. Register: the hell passages are the Law-28/29 stress test — punishments rendered as environments and phenomena (rivers of fire, hanging mists, wheels of flame), never as contact acts on figures; restraint is the craft. The heaven passages get the bright-blockbuster glory treatment. Close on the canon vote and the Ethiopian survival (rhyme with the series' Ethiopia motif). Runtime 55-70 min. Kling 12-15: gate-of-heaven hero, river-of-fire hero, the Muratorian scroll beat.

---

## SESSION PROTOCOL (containers reset — this is how work survives)
- Work in `/home/claude/bb4/`. One video at a time; do not start Part N+1 until Part N's src is gate-green.
- END OF EVERY SESSION: produce `bb4-wip.zip` containing every finished `<slug>-src/` dir, any in-flight river, and `STATE.md` (one paragraph: what is done, what is mid-flight, exact next action). Present it. Peter re-attaches it with the briefcase at the next session start; your first action is to unzip and read STATE.md.
- Rivers are written fresh per INSTRUCTIONS §1 Step 2 — river-first, READ pass, then chop. Never CSV-first.

## PLACEMENT STEP (post-chop, per film -- closes the tooling gap flagged 1 Aug)
`chop_river.py` does not write the `kling` column; placement is its own authored step, like the config. After chop and BEFORE intake: copy `templates/place_kling_TEMPLATE.py` to the src dir as `place_<slug>.py`, fill the three EDIT-ME zones only (tier sizes ~6-8 cold-open + 1 opener per act + 3-6 hero anchors = the slate's 12-15; the MOT dict in witness grammar), run it, confirm `contact self-check: []` and the BOM line, then run intake and expect the `kling:N(contig=True)` placement line in its report. `kling_count` in chop-config stays 0. Box-side ingest reads the column (landed, commit aafb983).

## FINAL DELIVERABLE (when all four are gate-green)
One zip `bb-next4.zip`:
```
bb-next4/
  gospel-of-thomas-src/      (7 files per INSTRUCTIONS Step 4)
  book-of-jasher-src/
  testament-of-solomon-src/
  apocalypse-of-peter-src/
  HANDOFF.md
```
HANDOFF.md carries, verbatim-ready: (1) LAPTOP: unzip + one `scp -P 443 -r` of the four dirs to `peter@116.202.18.68:Pipeline/sacred-dawn/projects/` (remote paths are relative to ~, keep the `Pipeline/` prefix); (2) BOX block A: venv + .env, then FOUR ingest commands chained with `&&` (each: `python shared/v2/ingest.py --src sacred-dawn/projects/<slug>-src --db sacred-dawn/projects/<slug>/<slug>.db --slug <slug> --channel sacred_dawn --title "..." --tags "..."` — voice/rate/category come from channel.json, expect the `kling placement column: N beats` line each time); (3) BOX block B: ONE tmux session running the four renders SEQUENTIALLY (one ffmpeg-heavy job at a time is law): `tmux new -d -s bb4 "bash -lc 'cd ~/Pipeline && source ~/venvs/pipeline/bin/activate && set -a && source .env && set +a && python -u shared/v2/render.py --project sacred-dawn/projects/gospel-of-thomas >> bb4.log 2>&1 && python -u shared/v2/render.py --project sacred-dawn/projects/book-of-jasher >> bb4.log 2>&1 && python -u shared/v2/render.py --project sacred-dawn/projects/testament-of-solomon >> bb4.log 2>&1 && python -u shared/v2/render.py --project sacred-dawn/projects/apocalypse-of-peter >> bb4.log 2>&1'"` — uploads land PRIVATE; Peter schedules in Studio. Include the `--status` monitor line per project and the resume rule (rerun the same render line; idempotent).

## STANDING CONSTRAINTS (restated so they cannot be missed)
- Laws 1-29 in _CANONICAL.md are binding; 25 (tag-words), 28 (contact physics + witness grammar + anchor + register map), 29 (mute-still on every cold-open/hero variant) get checked ON EVERY FILM.
- Kling is the authored `kling` column (Law 28e), truthy `1`, motion from that row's own `motion` cell, every prompt ends with `, natural documentary physics, restrained realistic motion`.
- Gates run FOR REAL, outputs pasted: negation grep, over-55 count (must be 0), audit tail (`AUDIT PASSED`), intake tail (`RESULT: GREEN`). A claimed gate without its pasted output does not count.
- Titles/tags above are locked; descriptions written per example-src/desc.txt shape; sections.json block "0" is exactly "COLD OPEN"; thumbsubject.txt one line, object-first, mute-still-passing.
- Law 35 is live in your intake: every config declares "character_archetypes" and "object_archetypes"; every act's token plan carries at least one of EACH class (hard-fail at zero of both). Characters use the face-safe staging menu (back-shot, profile, hands, hooded, distance); each story's iconic props get tokens; frozen event-stills (apex/aftermath) are required where the source has great events -- Law 28 governs motion only.
- Law 34 is live in your intake: every config MUST set "period_anchor" (Part VI example: "ancient world and 1945 Egyptian desert, pre-industrial and mid-century -- pick per frame-story at Step 0") plus "period_exempt_archetypes" for dream/cosmic/book-motif classes; every non-exempt canon+variant text carries the anchor verbatim, and road/street/town/city/lights never appear without material or light source named (packed earth, stone, oil-lamp, torch).
- Law 33 is live in your chop + intake: every config's block "0" MUST carry `"register": {"target_words": 20, "hardcap_words": 26, "merge_floor": 10, "aggressive_floor": 8, "aggressive_hardcap": 26}`; intake hard-fails any block-0 beat over 26 words. The feature register (42/55) is the GLOBAL setting and is earned from the body onward.
- Law 32 is live in your intake: no same-token run >3; no adjacent near-identical phenomena. Author dwells as COVERAGE -- long passages route through a token family, alternating, at route level.
- Do not modify the tools or any v2 code. Do not relitigate settled laws. If a gate cannot be made green or an instruction seems to conflict, STOP and say exactly where — do not improvise.
