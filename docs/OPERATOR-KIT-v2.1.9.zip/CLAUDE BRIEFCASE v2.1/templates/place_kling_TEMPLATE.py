"""place_kling_TEMPLATE.py -- the post-chop placement step (Law 28e).
COPY per film as place_<slug>.py, edit ONLY the three EDIT-ME zones, run in the
src dir AFTER chop and BEFORE intake. It adds the authored `kling` column +
per-row witness-grammar motion prompts to master.csv. The gated intake then
validates in placement mode; box-side ingest.py reads the column (fix-commit
aafb983). Rules baked in: motion = continuous phenomena in witness grammar,
every prompt ends with the physics anchor, the contact-verb self-check must
print []. Do not touch the mechanism below the EDIT-ME zones.
"""
import csv, re
rows = list(csv.DictReader(open('master.csv', encoding='ascii')))
for r in rows: r['kling'] = ''
# === EDIT-ME ZONE 1: token -> motion phrase (witness grammar, continuous phenomena only) ===
MOT = {
 "void_voice":"layers of darkness drift and breathe, faint deep pressure-waves rippling through the black",
 "first_light":"a wall of golden light pours outward through the darkness, filaments of radiance streaming and settling",
 "world_forming":"clouds stream over rising lands, seas settle into their basins, light sweeps slowly across new mountains",
 "ff_corridor":"torch flames flicker along the seabed as spray drifts off the towering water walls",
 "ff_ark":"rain streams in sheets, the wave crest foams and rolls, the small hull rides slowly over",
 "ff_carmel":"the column of fire pours downward, embers stream upward, robes stirring in the heat-wind",
 "ff_furnace":"white flame flows around the calm figures, heat-shimmer rising, light breathing",
 "ff_tomb":"dawn light creeps across the chamber floor as dust motes drift in the beam",
 "ff_riders":"banners and manes stream in the wind, dust drifting off the world's rim, the burning sky churning slowly",
 "burned_page":"embers lift and drift from the curling page edge, the flame-line creeping across the script",
 "eden_sanctuary":"golden light drifts between the great trunks, leaves stirring, river-water gliding over stones",
 "two_trees":"light shifts through the boughs, the bright tree's glow pulsing softly, leaves trembling",
 "serpent_coil":"coils glide slowly through dappled shade, leaf-shadow drifting across the scales",
 "exile_gate":"the blade of flame turns slowly, incense smoke rising straight, the guardians' light pulsing gently",
 "field_blood":"wind moves through the flattened grain, dust drifting under a bruised sky",
 "watcher_descent":"points of cold light descend the mountainside in slow ranks, radiance breathing",
 "giant_shapes":"dust drifts around the colossal silhouettes, distant herds scattering slowly, clouds churning",
 "enoch_ascent":"cloud-courts drift and glow, the small figure rising steadily through tiers of light",
 "giant_dreams":"dark water rises through the dream-garden, carved names dissolving off the sinking tablet in threads",
 "ark_storm":"mountainous swells roll under the hull, rain driving in sheets, spray streaming off the timbers",
 "mastema_shadow":"firelight flickers across the tall still figure, shadow breathing at the court's edge",
 "babel_tower":"kiln smoke climbs, dust drifting through the empty ramps, wind stirring loose grit",
 "sodom_fire":"lines of fire pour down the black sky, furnace-smoke columns climbing off the plain",
 "ram_thicket":"morning wind stirs the thorn branches, dust drifting across the summit light",
 "ladder_dream":"golden light pours down the living stair, luminous figures gliding both ways in slow traffic",
 "nile_basket":"reeds sway, river light rippling around the drifting basket",
 "burning_bush":"liquid fire flows over the green leaves, every leaf whole, heat-shimmer rising",
 "plague_sky":"the red river glides between temple banks, haze breathing over the water",
 "passover_door":"lamp flame trembles, moon-shadow drifting across the marked doorframe, a deeper darkness gliding past",
 "sea_corridor":"the water walls churn and hold, foam veins pulsing through the dark faces, wind scouring sand along the floor",
 "sinai_fire":"fire and smoke pour upward off the whole mountain, lightning pulsing inside the cloud",
 "angel_dictation":"fire-lit cloud drifts around the standing tablets, their engraved light pulsing, ink glistening",
 "calf_gold":"firelight flickers on the gold, smoke drifting over the camp",
 "david_sling":"dust drifts across the valley floor, banners stirring on both slopes, the sling cord blurring in a slow arc",
 "throne_covenant":"lamplight breathes on the crown and staff, night air stirring in the cedar room",
 "temple_glory":"luminous cloud pours through the inner doors, gold light blooming, robes stirring as the priests withdraw",
 "carmel_altar":"the fire-column pours from the dark sky, steam and embers streaming upward, the trench water boiling away",
 "fire_chariot":"flame-horses and wheel-fire stream upward in a slow spiral, the mantle drifting down through sparks",
 "assyria_storm":"siege smoke drifts across the plain, spear-ranks shimmering in the heat",
 "temple_burning":"flame sheets pour from the roofline, the smoke column climbing into night, firelight rippling on stone",
 "wheel_eyes":"the wheels turn within wheels in impossible stillness, eye-rims glinting, storm-fire breathing around them",
 "furnace_four":"white fire flows around the walking figures, the ropes charring away, heat-light breathing",
 "return_road":"road dust drifts behind the caravan, evening light moving slow across the hills",
 "manger_light":"lantern glow breathes, straw dust drifting, the hosts' radiance pulsing across the night fields",
 "city_gates":"palm branches wave, cloaks rippling on the road, dust drifting through the crowd light",
 "garden_tomb":"dawn light creeps into the chamber, dust motes drifting, the folded linen catching first gold",
 "wind_flames":"small flames stand and breathe on every bowed head, garments stirring in the unseen wind",
 "damascus_light":"white radiance pours down over the fallen man, dust drifting in the blaze, robes pressed flat by the light",
 "patmos_seer":"sea wind stirs the white hair and robe, spray drifting up the headland",
 "riders_four":"the four horses surge slowly forward, manes and banners streaming, dust rolling off the rim under a churning burning sky",
 "new_city":"the radiant city descends slowly through parting heavens, light blooming off the jasper walls, the crystal river glinting",
}
ANCHOR = ", natural documentary physics, restrained realistic motion"  # never edit
by_block = {}
for i, r in enumerate(rows): by_block.setdefault(r['block_id'], []).append(i)
placed = set()
for i in by_block['0']: placed.add(i)
# === EDIT-ME ZONE 2: tier sizes -- TIER1_TOTAL beats of cold-open saturation, openers-per-act ===
TIER1_TOTAL = 8   # spokes: 6-8 (the epic used 30); block 0 first, spill into block 1
OPENERS_PER_ACT = 1  # spokes: 1 (the epic used 2)
for i in by_block['1'][:max(0, TIER1_TOTAL-len(by_block['0']))]: placed.add(i)
tier1 = len(placed)
for b in range(2, 1 + max(int(r['block_id']) for r in rows)):
    for i in by_block[str(b)][:OPENERS_PER_ACT]: placed.add(i)
tier12 = len(placed)
# === EDIT-ME ZONE 3: hero placements -- (block, token, text-anchor regex), 3-6 per spoke ===
T3 = [
 ('3','example_hero_token', r"exact words from that beat's narration"),
]
miss = []
for b, tok, rx in T3:
    hit = None
    for i in by_block[b]:
        if rows[i]['subject']==tok and re.search(rx, rows[i]['narration']) and i not in placed:
            hit = i; break
    if hit is None:
        for i in by_block[b]:
            if rows[i]['subject']==tok and i not in placed:
                hit = i; break
    if hit is None: miss.append((b,tok))
    else: placed.add(hit)
for i in placed:
    rows[i]['kling'] = '1'
    rows[i]['motion'] = MOT.get(rows[i]['subject'], "light drifts and settles across the scene, the air breathing") + ANCHOR
CONTACT = re.compile(r"(?i)\b(jump\w*|crack\w*|explod\w*|slid\w*\s+out|burst\w*|shatter\w*|strik\w*|smash\w*|collid\w*|impact\w*|crash\w*)\b")
bad = sorted(set(rows[i]['subject'] for i in placed if CONTACT.search(rows[i]['motion'])))
fields = list(rows[0].keys())
if 'kling' not in fields: fields.append('kling')
with open('master.csv','w',newline='',encoding='ascii') as f:
    w = csv.DictWriter(f, fieldnames=fields); w.writeheader()
    for r in rows: w.writerow(r)
n = len(placed)
print(f"placed: tier1={tier1} tier2={tier12-tier1} tier3={n-tier12} TOTAL={n}")
print(f"misses={miss} | contact self-check: {bad}")
print(f"BOM: {len(rows)*.08:.2f} stills + {n*.42:.2f} kling + ~1.00 = ${len(rows)*.08 + n*.42 + 1.0:.2f}")
